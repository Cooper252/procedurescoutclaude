# Going live: everything still needed (2026-11-10)

Plain-language checklist. **Owner** says who does it. Costs are monthly unless
noted and were checked 2026-11-08 to 2026-11-09 (see DEPLOYMENT_PLAN.md).

## 1. Decisions only Cooper can make

| # | Decision | Why it matters |
|---|---|---|
| Q35 | **Publish each hospital's first price file automatically** when every check passes (has prices, no file problems, at most 1% of rows refused)? Today a person must approve every hospital's first file. | About 6,000 hospitals nationally: approving each first file by hand isn't realistic. Refreshes already publish automatically (D-035). The live-load run has a tick box for this. |
| Q36 | **Domain name**: which address the site lives at (for example procedurescout.com, if you still own it). | Needed for the website, sign-in emails and Resend. |
| Q25 | **Lawyer review** of the terms of use, privacy notice and disclaimers (English and Spanish), the review rules, and health-data privacy laws. | Should happen before the public launch. |
| Q22 | Confirm the Nevada uninsured-discount law (NRS 439B.260) before it is shown. | Nevada only; can be hidden until confirmed. |

## 2. Accounts to create (Cooper, with Claude walking through each screen)

| Account | Cost | Notes |
|---|---|---|
| Render (website, API, database) | about $53 | `render.yaml` sets everything up. |
| Cloudflare R2 (published price files) | under $1 at first | 10 GB free; about 55 GB nationally ≈ $1. |
| Resend (email) | free to 3,000 a month | Verify the domain; switchable to Amazon SES later. |
| Domain name DNS | ~$10–20 a year if not already owned | Point it at Render. |
| Stripe | none until charging | Only when you decide to charge (D-051). |

After sign-up: add the GitHub secrets for the live-load run, run `add-staff` for each reviewer, and check `/healthz`, a search and the review pages.

## 3. Loading the country (Claude runs, Cooper clicks "Run workflow")

- **Run "Load a state into the live site"** for each state (`load-state-production.yml`). Each run: reference data, hospital websites (found and checked automatically), price files (published one at a time, staged rows removed), offices from the national provider list, code index, insurance names.
- **Big states may exceed GitHub's 6-hour limit** per run (California, Texas, Florida, New York). If so, those states get split into parts; measure on a mid-size state first.
- **Insurance names per state**: matched automatically when certain; Claude researches the rest with evidence (D-047).
- **Help paying, per state** (still to do, Claude researches, Cooper approves each state's list once): Medicaid and children's coverage income limits (only Nevada so far), marketplace notes, and the state's 211 link.
- **Hospital financial-assistance policies**: only 13 Nevada policies proposed so far; national coverage is a later step (the site says "ask about financial assistance" until a policy is reviewed).

## 4. Built and ready (no action needed)

Search, provider pages, accounts with the authenticator app, reviews, provider prices and specials, counts, wrong-price reports, review pages with per-person logins, email sending, rate limits, billing (off), offices from the national provider list (tested on real Nevada data: 8,238 offices), any-state runs, automatic website checks, file-by-file publishing.

## 5. Before opening to the public (Claude unless noted)

- First live load (Nevada), then check the hosted site end to end in a browser: search, a provider page, sign-in email arrives, a review, the review pages.
- A person tries the site with a screen reader (automatic checks pass).
- A Spanish speaker reads the Spanish pages (Cooper finds someone).
- Turn on Render's database backups and an uptime check (Render includes both on paid plans; confirm at sign-up).
- Remove `PORTAL_DEV_LINKS` (it's off in production automatically).
